package dev.pranav.applock

import android.app.Application
import android.content.Context
import android.util.Log
import dev.pranav.applock.core.utils.LogUtils
import dev.pranav.applock.data.repository.AppLockRepository
import kotlin.concurrent.thread

class AppLockApplication : Application() {

    lateinit var appLockRepository: AppLockRepository
        private set

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
    }

    override fun onCreate() {
        super.onCreate()
        initializeComponents()

        LogUtils.initialize(this)
        LogUtils.setLoggingEnabled(appLockRepository.isLoggingEnabled())
        // Purge logs older than 3 days on every app start (run in background to avoid ANR)
        thread(start = true, name = "LogPurge") {
            LogUtils.purgeOldLogs()
        }
    }

    private fun initializeComponents() {
        try {
            appLockRepository = AppLockRepository(this)
            Log.d(TAG, "Application components initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize application components", e)
        }
    }

    companion object {
        private const val TAG = "AppLockApplication"
    }
}
