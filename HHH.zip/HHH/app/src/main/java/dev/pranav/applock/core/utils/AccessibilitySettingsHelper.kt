package dev.pranav.applock.core.utils

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Checks whether this app's accessibility service is enabled by the user. */
fun Context.isAccessibilityServiceEnabled(): Boolean {
    val serviceName = "$packageName/$packageName.services.AppLockAccessibilityService"
    val enabledServices = Settings.Secure.getString(
        contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    )
    return enabledServices?.contains(serviceName) == true ||
        enabledServices?.contains("$packageName/.services.AppLockAccessibilityService") == true
}

/** Opens Android's accessibility settings; the user must enable the service manually. */
fun openAccessibilitySettings(context: Context) {
    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
}
