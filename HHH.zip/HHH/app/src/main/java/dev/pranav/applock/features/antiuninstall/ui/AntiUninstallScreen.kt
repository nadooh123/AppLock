package dev.pranav.applock.features.antiuninstall.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun AntiUninstallScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Anti-uninstall protection", style = MaterialTheme.typography.headlineSmall)
        Text(
            "This feature is unavailable in this version. Android does not allow an ordinary app to reliably prevent its own removal without elevated privileges or device-owner management.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
